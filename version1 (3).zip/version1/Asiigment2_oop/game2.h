#ifndef GAME2_H
#define GAME2_H

#include <QDialog>
#include <QPushButton>

namespace Ui {
class Game2;
}

class Game2 : public QDialog
{
    Q_OBJECT

public:
    explicit Game2(QWidget *parent = nullptr);
    ~Game2();

private slots:
    void on_playVsRandomButton_clicked();
    void on_playVsSecondButton_clicked();
    void on_helpButton_clicked();
    void on_backButton_clicked();
    void blockSmallGrid(int gridRow, int gridCol);
    void drawLargeSymbol(int gridRow, int gridCol);
    void on_newGameButton_clicked();

private:
    void setupGameBoard();
    void handleCellClick(int gridRow, int gridCol, int row, int col);
    void updateGameState(int gridRow, int gridCol, int row, int col, const QString &symbol);
    void switchPlayer();
    bool checkSmallGridWinner(int gridRow, int gridCol);
    bool checkWinner();
    void resetBoard();
    void enableboard();
    void disableboard();
    void getmove(int&x , int& y);
    bool isRandomPlayerActive = false;
    bool gameover = false;
    bool isSmallGridFull(int gridRow, int gridCol);

    Ui::Game2 *ui;

    // Game state variables
    QString player1Name, player2Name;
    QString player1Symbol, player2Symbol;
    QString currentPlayer, currentSymbol;

    // Arrays to manage the game state
    QPushButton* boardButtons[3][3][3][3];  // Array for buttons in the grid
    bool gameBoard[3][3][3][3];              // Array to track occupied cells
    bool smallGridOccupied[3][3];            // Array for small grid occupancy

};

#endif // GAME2_H
