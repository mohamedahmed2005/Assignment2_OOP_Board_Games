#ifndef GAME1_H
#define GAME1_H

#include <QDialog>

namespace Ui {
class Game1;
}

class Game1 : public QDialog
{
    Q_OBJECT

public:
    explicit Game1(QWidget *parent = nullptr);
    ~Game1();

private slots:
    void on_playVsRandomButton_clicked();
    void on_playVsSecondButton_clicked();
    void on_helpButton_clicked();
    void on_newGameButton_clicked();
    void on_backButton_clicked();
private:
    bool checkWinner();
    void handleCellClick(QPushButton *cellButton);
    void switchPlayer();
    void updatePlayerLabel();
    QString player1Name;
    QString player2Name;
    QString player1Symbol;
    QString player2Symbol;
    QString currentPlayer;
    QString currentSymbol;
    QPushButton* gridButtons[4][4]; // Declare the 4x4 grid buttons
    void resetBoard();


private:
    Ui::Game1 *ui;
};

#endif // GAME1_H
