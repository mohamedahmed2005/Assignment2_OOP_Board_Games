#include "games_menu.h"
#include "ui_games_menu.h"
#include "game1.h"
#include "game2.h"
#include "mainwindow.h"

GamesMenu::GamesMenu(QWidget *parent) : QDialog(parent), ui(new Ui::GamesMenu) {
    ui->setupUi(this);
}

GamesMenu::~GamesMenu() {
    delete ui;
}

void GamesMenu::on_playGame1Button_clicked() {
    Game1 *game1Window = new Game1(this);
    game1Window->show();
    this->hide();
}

void GamesMenu::on_playGame2Button_clicked() {
    Game2 *game2Window = new Game2(this);
    game2Window->show();
    this->hide();
}

void GamesMenu::on_backButton_clicked() {
    MainWindow *mainWindow = new MainWindow();
    mainWindow->show();
    this->close();
}
