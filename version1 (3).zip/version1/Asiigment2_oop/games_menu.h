#ifndef GAMESMENU_H
#define GAMESMENU_H

#include <QDialog>

namespace Ui {
class GamesMenu;
}

class GamesMenu : public QDialog
{
    Q_OBJECT

public:
    explicit GamesMenu(QWidget *parent = nullptr);
    ~GamesMenu();

private slots:
    void on_playGame1Button_clicked();
    void on_playGame2Button_clicked();
    void on_backButton_clicked();

private:
    Ui::GamesMenu *ui;
};

#endif // GAMESMENU_H
