#ifndef GAME1_H
#define GAME1_H

#include <QDialog>

namespace Ui {
class Game1;
}

class Game1 : public QDialog
{
    Q_OBJECT

public:
    explicit Game1(QWidget *parent = nullptr);
    ~Game1();

private slots:
    void on_playVsRandomButton_clicked();
    void on_playVsSecondButton_clicked();
    void on_manualButton_clicked();
    void on_newGameButton_clicked();
    void findCellPosition(QPushButton *cellButton, int &row, int &col);
    bool isAdjacent(QPushButton *fromCell, QPushButton *toCell);

private:
    QPushButton* selectedCell = nullptr;  // Track the selected cell (token)
    bool checkWinner();
    void handleCellClick(QPushButton *cellButton);
    void switchPlayer();
    QString player1Name;
    QString player2Name;
    QString player1Symbol;
    QString player2Symbol;
    QString currentPlayer;
    QString currentSymbol;
    QPushButton* gridButtons[4][4]; // Declare the 4x4 grid buttons
    void resetBoard();
    bool isRandomPlayerActive = false;



private:
    Ui::Game1 *ui;
};

#endif // GAME1_H
