#include "game1.h"
#include "ui_game1.h"
#include "games_menu.h"
#include <QInputDialog>
#include <QMessageBox>
#include <QVBoxLayout>
#include "BoardGame_Classes.h"
#include<QTimer>
static int turn = 0;

Game1::Game1(QWidget *parent) : QDialog(parent), ui(new Ui::Game1) {
    ui->setupUi(this);
    // Hide boardWidget initially
    ui->boardWidget->hide();
    // Hide current player label
    ui->currentPlayerLabel->hide();

    // Create a vertical layout for centering the grid
    QVBoxLayout *boardLayout = new QVBoxLayout(ui->boardWidget);
    boardLayout->setAlignment(Qt::AlignCenter); // Center align the grid
    ui->boardWidget->setLayout(boardLayout);

    // Set up the 4x4 grid within boardWidget
    const int gridSize = 4;
    const int cellSize = 90;
    QGridLayout *gridLayout = new QGridLayout();
    gridLayout->setSpacing(10); // Space between buttons
    gridLayout->setContentsMargins(0, 0, 0, 0); // Remove margins

    for (int row = 0; row < gridSize; ++row) {
        for (int col = 0; col < gridSize; ++col) {
            QPushButton *cellButton = new QPushButton(ui->boardWidget);
            cellButton->setFixedSize(cellSize, cellSize);
            cellButton->setStyleSheet(
                "QPushButton {"
                "background-color: #B2FF59;"      // Light green background
                "border-radius: 20px;"
                "border: 3px solid #66BB6A;"     // Green border
                "font-size: 30px;"
                "font-weight: bold;"
                "color: #388E3C;"                // Green text color
                "} "
                "QPushButton:hover {"
                "background-color: #A5D6A7;"     // Lighter green on hover
                "} "
                "QPushButton:pressed {"
                "background-color: #81C784;"     // Even lighter green on press
                "border: 3px solid #388E3C;"
                "} ");

            gridLayout->addWidget(cellButton, row, col);

            // Store in an array for further management
            gridButtons[row][col] = cellButton;

            // Connect to the click handler
            connect(cellButton, &QPushButton::clicked, this, [this, cellButton]() {
                handleCellClick(cellButton);
            });
        }
    }
    resetBoard();

    // Add the grid layout to the vertical layout
    boardLayout->addLayout(gridLayout);

    currentPlayer = "Player 1";
    currentSymbol = "X";
    // switchPlayer();
    ui->newGameButton->hide();
}

void Game1::on_manualButton_clicked() {
    // Build the message with detailed game rules
    QString rulesMessage =
        "Game ends in a draw. 7-4 x 4 Tic-Tac-Toe\n\n"
        "4 x 4 Tic-Tac-Toe is an extended version of the classic game, played on a larger board with more "
        "complex strategies. Each player has four tokens and aims to align three tokens in a row to win. "
        "This game introduces new movement rules and strategic depth to the traditional Tic-Tac-Toe.\n\n"
        "The game is played on a 4x4 grid. Each player has four tokens. Tokens are placed in specific starting positions: "
        "two tokens on opposite sides of the board for each player. (First board is initialized by O X O X and the last row "
        "initialized by X O X O).\n\n"
        "Rules:\n"
        "Players alternate turns, moving one of their tokens to an immediately adjacent open square. "
        "Tokens can be moved horizontally or vertically but not diagonally. Tokens may not jump over other tokens.\n\n"
        "The goal is to align three of your tokens in a row. This can be achieved horizontally, vertically, or diagonally.\n\n"
        "Winning: The first player to get three tokens in a row wins the game. The alignment can be horizontal, vertical, "
        "or diagonal.";

    // Show the message in a QMessageBox
    QMessageBox::information(this, "Help", rulesMessage);
}




Game1::~Game1() {
    delete ui;
}

void Game1::on_playVsRandomButton_clicked() {
    bool ok;

    player2Name = "Mr. Habida";
    QStringList symbols = {"X", "O"};
    do {
        player1Name = QInputDialog::getText(this, "Player 1 Name", "Enter Player 1's name:", QLineEdit::Normal, "", &ok);
        if (!ok || player1Name.isEmpty()) return;

        // Check if Player 1's name is the same as Player 2's (which is "Mr. Habida")
        if (player1Name == player2Name) {
            QMessageBox::warning(this, "Name Error", "Player 1's name cannot be 'Mr. Habida'. Please choose a different name.");
        }
    } while (player1Name == player2Name);  // Repeat if the names are the same
    player1Symbol = QInputDialog::getItem(this, "Choose Symbol", "Choose Player 1's symbol:", symbols, 0, false, &ok);
    if (!ok || player1Symbol.isEmpty()) return;

    symbols.removeAll(player1Symbol);
    player2Symbol = symbols[0];

    currentPlayer = player1Name;
    currentSymbol = player1Symbol;
    isRandomPlayerActive = true;

    ui->playVsRandomButton->setVisible(false);
    ui->playVsSecondButton->setVisible(false);
    ui->newGameButton->setVisible(true);
    ui->boardWidget->show();
    ui->currentPlayerLabel->show();
    ui->currentPlayerLabel->setText("Current Player: " + currentPlayer + " with symbol " + currentSymbol);
    ui->currentPlayerLabel->setStyleSheet("color: #ffffff; font-size: 20px; font-family: 'Arial', sans-serif;");
}

void Game1::on_playVsSecondButton_clicked() {
    bool ok;

    // Get Player 1's name
    player1Name = QInputDialog::getText(this, "Player 1 Name", "Enter Player 1's name:", QLineEdit::Normal, "", &ok);
    if (!ok || player1Name.isEmpty()) return;

    // Get Player 2's name and check if it's the same as Player 1's name
    do {
        player2Name = QInputDialog::getText(this, "Player 2 Name", "Enter Player 2's name:", QLineEdit::Normal, "", &ok);
        if (!ok || player2Name.isEmpty()) return;
        if (player2Name == player1Name) {
            QMessageBox::warning(this, "Name Error", "Player 2's name cannot be the same as Player 1's name. Please choose a different name.");
        }
    } while (player2Name == player1Name);  // Repeat until Player 2 enters a different name

    // Choose Player 1's symbol
    QStringList symbols = {"X", "O"};
    player1Symbol = QInputDialog::getItem(this, "Choose Symbol", "Choose Player 1's symbol:", symbols, 0, false, &ok);
    if (!ok || player1Symbol.isEmpty()) return;

    // Remove the chosen symbol from the list and assign the remaining symbol to Player 2
    symbols.removeAll(player1Symbol);
    player2Symbol = symbols[0];


    // Display game setup information
    QMessageBox::information(this, "Game Setup", "Player 1: " + player1Name + " (" + player1Symbol + ")\nPlayer 2: " + player2Name + " (" + player2Symbol + ")");

    currentPlayer = player1Name;
    currentSymbol = player1Symbol;

    ui->playVsRandomButton->setVisible(false);
    ui->playVsSecondButton->setVisible(false);
    ui->newGameButton->setVisible(true);
    ui->boardWidget->show();
    ui->currentPlayerLabel->show();
    ui->currentPlayerLabel->setText("Current Player: " + currentPlayer + " with symbol " + currentSymbol);
    ui->currentPlayerLabel->setStyleSheet("color: #ffffff; font-size: 20px; font-family: 'Arial', sans-serif;");
}



bool Game1::checkWinner() {
    // Check for horizontal win (3 consecutive tokens in a row)
    for (int row = 0; row < 4; ++row) {
        for (int col = 0; col < 2; ++col) {  // Only check up to col 1 for a 3-cell sequence
            if (gridButtons[row][col]->text() == currentSymbol &&
                gridButtons[row][col + 1]->text() == currentSymbol &&
                gridButtons[row][col + 2]->text() == currentSymbol) {
                return true;
            }
        }
    }

    // Check for vertical win (3 consecutive tokens in a column)
    for (int col = 0; col < 4; ++col) {
        for (int row = 0; row < 2; ++row) {  // Only check up to row 1 for a 3-cell sequence
            if (gridButtons[row][col]->text() == currentSymbol &&
                gridButtons[row + 1][col]->text() == currentSymbol &&
                gridButtons[row + 2][col]->text() == currentSymbol) {
                return true;
            }
        }
    }

    // Check for diagonal win (3 consecutive tokens in a diagonal)
    // Top-left to bottom-right diagonal
    for (int row = 0; row < 2; ++row) {  // Only check rows 0 and 1 for a 3-cell diagonal
        for (int col = 0; col < 2; ++col) {  // Only check columns 0 and 1 for a 3-cell diagonal
            if (gridButtons[row][col]->text() == currentSymbol &&
                gridButtons[row + 1][col + 1]->text() == currentSymbol &&
                gridButtons[row + 2][col + 2]->text() == currentSymbol) {
                return true;
            }
        }
    }

    // Bottom-left to top-right diagonal
    for (int row = 2; row < 4; ++row) {  // Only check rows 2 and 3 for a 3-cell diagonal
        for (int col = 0; col < 2; ++col) {  // Only check columns 0 and 1 for a 3-cell diagonal
            if (gridButtons[row][col]->text() == currentSymbol &&
                gridButtons[row - 1][col + 1]->text() == currentSymbol &&
                gridButtons[row - 2][col + 2]->text() == currentSymbol) {
                return true;
            }
        }
    }

    return false;  // No winner found
}


void Game1::on_newGameButton_clicked() {
    turn = 0;
    resetBoard();
    ui->playVsRandomButton->setVisible(true);
    ui->playVsSecondButton->setVisible(true);
    ui->newGameButton->setVisible(false);
    ui->boardWidget->hide();
    ui->currentPlayerLabel->hide();
    isRandomPlayerActive = false;

}

void Game1::resetBoard() {
    // Initialize the board with the starting tokens and apply styles
    QString initialBoard[4][4] = {
        {"O", "X", "O", "X"},  // First row
        {"", "", "", ""},      // Second row (empty)
        {"", "", "", ""},      // Third row (empty)
        {"X", "O", "X", "O"}   // Last row
    };

    for (int row = 0; row < 4; ++row) {
        for (int col = 0; col < 4; ++col) {
            QPushButton *cellButton = gridButtons[row][col];
            if (cellButton) {
                // Set initial text based on the starting positions
                cellButton->setText(initialBoard[row][col]);

                // Apply style
                cellButton->setStyleSheet(
                    "QPushButton {"
                    "background-color: #B2FF59;"    // Light green background
                    "border-radius: 20px;"
                    "border: 3px solid #66BB6A;"   // Green border
                    "font-size: 30px;"
                    "font-weight: bold;"
                    "color: #388E3C;"               // Green text color
                    "} "
                    "QPushButton:hover {"
                    "background-color: #A5D6A7;"    // Lighter green on hover
                    "} "
                    "QPushButton:pressed {"
                    "background-color: #81C784;"    // Even lighter green on press
                    "border: 3px solid #388E3C;"
                    "} ");

                // Style tokens already placed (X or O)
                if (initialBoard[row][col] == "X") {
                    cellButton->setStyleSheet(
                        "color: red; font-size: 24px; font-weight: bold;"
                        );
                } else if (initialBoard[row][col] == "O") {
                    cellButton->setStyleSheet(
                        "color: blue; font-size: 24px; font-weight: bold;"
                        );
                }
            }
        }
    }
    selectedCell = nullptr;

}


void Game1::handleCellClick(QPushButton *cellButton) {
    if (selectedCell != nullptr && cellButton->text().isEmpty() && isAdjacent(selectedCell, cellButton)) {
        // Move the token to the clicked cell
        cellButton->setText(selectedCell->text());
        cellButton->setStyleSheet("color: " + QString(selectedCell->text() == "X" ? "red" : "blue") + "; font-size: 24px; font-weight: bold;");

        // Clear the old cell
        selectedCell->setText("");
        selectedCell->setStyleSheet("background-color: #B2FF59; border-radius: 20px; border: 3px solid #66BB6A; font-size: 30px; font-weight: bold; color: #388E3C;");

        // Clear the selected cell
        selectedCell = nullptr;

        // Check if the player has won after the move
        if (checkWinner()) {
            QMessageBox::information(this, "Game Over", currentPlayer + " wins!");
            resetBoard();
        } else {

            switchPlayer();
        }
    }
    // If the cell contains a token (current player symbol), select it to move
    else if (cellButton->text() == currentSymbol) {
        // If a token was already selected, reset its style
        if (selectedCell != nullptr) {
            selectedCell->setStyleSheet(
                "QPushButton {"
                "background-color: #B2FF59;"
                "border-radius: 20px;"
                "border: 3px solid #66BB6A;"
                "font-size: 30px;"
                "font-weight: bold;"
                "color: #388E3C;"
                "} "
                "QPushButton:hover {"
                "background-color: #A5D6A7;"
                "} "
                "QPushButton:pressed {"
                "background-color: #81C784;"
                "border: 3px solid #388E3C;"
                "} "
                );

            if (cellButton->text() == "X") {
                cellButton->setStyleSheet("color: red; font-size: 24px; font-weight: bold;");
            } else if (cellButton->text() == "O") {
                cellButton->setStyleSheet("color: blue; font-size: 24px; font-weight: bold;");
            }
        }

        // Set the new selected cell and highlight it with a different style
        selectedCell = cellButton;
        cellButton->setStyleSheet("border: 3px solid #FF5722; font-size: 24px; font-weight: bold;");

    }
    // If no valid move or token is selected, unhighlight the previously selected token
    else {
        if (selectedCell != nullptr) {
            selectedCell->setStyleSheet(
                "QPushButton {"
                "background-color: #B2FF59;"
                "border-radius: 20px;"
                "border: 3px solid #66BB6A;"
                "font-size: 30px;"
                "font-weight: bold;"
                "color: #388E3C;"
                "} "
                "QPushButton:hover {"
                "background-color: #A5D6A7;"
                "} "
                "QPushButton:pressed {"
                "background-color: #81C784;"
                "border: 3px solid #388E3C;"
                "} "
                );
            if (cellButton->text() == "X") {
                cellButton->setStyleSheet("color: red; font-size: 24px; font-weight: bold;");
            } else if (cellButton->text() == "O") {
                cellButton->setStyleSheet("color: blue; font-size: 24px; font-weight: bold;");
            }
        }
    }
}


bool Game1::isAdjacent(QPushButton *fromCell, QPushButton *toCell) {
    int fromRow, fromCol, toRow, toCol;

    // Find the positions of the fromCell and toCell in the grid
    findCellPosition(fromCell, fromRow, fromCol);
    findCellPosition(toCell, toRow, toCol);

    // Check if they are adjacent (horizontally or vertically)
    return (abs(fromRow - toRow) == 1 && fromCol == toCol) || (abs(fromCol - toCol) == 1 && fromRow == toRow);
}

void Game1::findCellPosition(QPushButton *cellButton, int &row, int &col) {
    for (int r = 0; r < 4; ++r) {
        for (int c = 0; c < 4; ++c) {
            if (gridButtons[r][c] == cellButton) {
                row = r;
                col = c;
                return;
            }
        }
    }
}


void Game1::getRandomMove() {
    currentSymbol = player2Symbol;
    int x, y, oldX_pos, oldY_pos;

    // Find the current position of the symbol
    do {
        oldX_pos = rand() % 4;
        oldY_pos = rand() % 4;
    } while (gridButtons[oldX_pos][oldY_pos]->text().isEmpty() || gridButtons[oldX_pos][oldY_pos]->text() != currentSymbol);

    // Determine the random direction to move
    int direction = rand() % 4; // 0 = left, 1 = right, 2 = up, 3 = down

    // Set new position based on direction
    x = oldX_pos;
    y = oldY_pos;

    switch (direction) {
    case 0: // Move left
        if (y > 0) {
            y--;
        }
        break;
    case 1: // Move right
        if (y < 3) {
            y++;
        }
        break;
    case 2: // Move up
        if (x > 0) {
            x--;
        }
        break;
    case 3: // Move down
        if (x < 3) {
            x++;
        }
        break;
    }

    // Check if the target cell is empty and valid for the move
    if (gridButtons[x][y]->text().isEmpty()) {
        // Clear the old cell
        gridButtons[oldX_pos][oldY_pos]->setText("");
        gridButtons[oldX_pos][oldY_pos]->setStyleSheet("background-color: #B2FF59; border-radius: 20px; border: 3px solid #66BB6A; font-size: 30px; font-weight: bold; color: #388E3C;");

        // Place the symbol in the new cell
        gridButtons[x][y]->setText(currentSymbol);
        gridButtons[x][y]->setStyleSheet("color: " + QString(currentSymbol == "X" ? "red" : "blue") + "; font-size: 24px; font-weight: bold;");

        // Show a message box with details
        // QMessageBox::information(
        //     this,
        //     "Move Info",
        //     QString("Symbol moved from (%1, %2) to (%3, %4)")
        //         .arg(oldX_pos)
        //         .arg(oldY_pos)
        //         .arg(x)
        //         .arg(y)
        //     );
    } else {
        // If the move is invalid, retry
        getRandomMove();
    }
    if (checkWinner()) {
        QMessageBox::information(this, "Game Over", currentPlayer + " wins!");
        resetBoard();
        return;
    }
    currentSymbol = player1Symbol;
    currentPlayer = player1Name;
    ui->currentPlayerLabel->setText("Current Player: " + currentPlayer + " with symbol " + currentSymbol);
    ui->currentPlayerLabel->setStyleSheet("color: #ffffff; font-size: 20px; font-family: 'Arial', sans-serif;");

}


void Game1::switchPlayer() {
    ui->currentPlayerLabel->setText("Current Player: " + currentPlayer + " with symbol " + currentSymbol);
    ui->currentPlayerLabel->setStyleSheet("color: #ffffff; font-size: 20px; font-family: 'Arial', sans-serif;");

    // Check if the current player has won
    if (checkWinner()) {
        QMessageBox::information(this, "Game Over", currentPlayer + " wins!");
        resetBoard();
        return;
    }

    // Switch player logic
    if (currentPlayer == player1Name) {
        // Switch to Player 2
        currentPlayer = player2Name;
        currentSymbol = player2Symbol;

        // If Player 2 is a random player, trigger their move
        if (isRandomPlayerActive) {
            ui->currentPlayerLabel->setText("Current Player: " + currentPlayer + " with symbol " + currentSymbol);
            ui->currentPlayerLabel->setStyleSheet("color: #ffffff; font-size: 20px; font-family: 'Arial', sans-serif;");

            // Use a timer to simulate delay for the random move
            QTimer::singleShot(500, this, &Game1::getRandomMove);
            return; // Wait for the random move to complete before switching back
        }
    } else {
        // Switch to Player 1
        currentPlayer = player1Name;
        currentSymbol = player1Symbol;
    }

    // Update the UI for the current player
    ui->currentPlayerLabel->setText("Current Player: " + currentPlayer + " with symbol " + currentSymbol);
    ui->currentPlayerLabel->setStyleSheet("color: #ffffff; font-size: 20px; font-family: 'Arial', sans-serif;");
}

