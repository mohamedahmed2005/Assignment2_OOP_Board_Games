#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void applyStylesheet();
    void on_startGameButton_clicked();
    void on_manualButton_clicked();  // Slot for the manualButton click
    void on_quitButton_clicked();    // Slot for the quitButton click
    void on_playGame1Button_clicked();
    void on_playGame2Button_clicked();
private:
    Ui::MainWindow *ui;
    bool buttonsVisible = false; // Tracks button visibility
    bool gameRunning = false;   // Tracks if a game is running
};

#endif // MAINWINDOW_H
