#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "games_menu.h"
#include <QMessageBox>
#include <QCloseEvent>
#include <QFile>
#include <QTextStream>
#include "game1.h"
#include "game2.h"
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    applyStylesheet();
    ui->beemo->setFixedSize(300, 300);
    ui->playGame1Button->hide();
    ui->playGame2Button->hide();
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_startGameButton_clicked() {
    // Toggle visibility of play buttons
    buttonsVisible = !buttonsVisible;
    if (buttonsVisible) {
        ui->playGame1Button->show();
        ui->playGame2Button->show();
    } else {
        ui->playGame1Button->hide();
        ui->playGame2Button->hide();
    }
}

void MainWindow::on_manualButton_clicked()
{
    // Build the welcome message with game names, play modes, and team copyright information
    QString welcomeMessage =
        "<h2>Welcome to the Ultimate XO and 4x4 Tic-Tac-Toe!</h2>"
        "<p>Choose your mode and enjoy:</p>"
        "<ul>"
        "<li><b>Play with a Random Player</b> - Challenge a random opponent Called 'Mr. Habida'!</li>"
        "<li><b>2-Player Mode</b> - Play against your friend!</li>"
        "</ul>"
        "<p><b>Game 1: Ultimate XO</b> - A strategic variation of the classic Tic-Tac-Toe, with exciting new rules!</p>"
        "<p><b>Game 2: 4x4 Tic-Tac-Toe</b> - The extended version of Tic-Tac-Toe, played on a 4x4 grid with deeper strategies!</p>"
        "<br>"
        "<p><i>&copy; 2024 TSociaty:</i><br>"
        "Amr El-Dahshan, Youssef Hassan, Mohammed Abd El-Wahab</p>";

    // Display the welcome message in a styled QMessageBox
    QMessageBox::information(this, "Welcome to the Game!", welcomeMessage);
}

void MainWindow::on_quitButton_clicked()
{
    // Confirm quit and close the application
    int ret = QMessageBox::warning(this, "Quit", "Are you sure you want to quit?",
                                   QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (ret == QMessageBox::Yes)
        QApplication::quit();
}

void MainWindow::applyStylesheet() {
    QString style = R"(
        /* Main Window Styling */
        QMainWindow {
            background-color: #2D3B48; /* Soft dark background for comfort */
            color: #E0E5E8; /* Soft text color */
            border-radius: 12px;
            font-family: 'Poppins', Arial, sans-serif; /* Modern font */
            padding: 10px;
        }

        /* QLabel (Beemo Image) Styling */
        QLabel#beemo {
            border-radius: 50%;
            border: 6px solid #76EEC6; /* Gentle turquoise to match Beemo */
            background-color: #3E5363;
            box-shadow: 0px 8px 20px rgba(118, 238, 198, 0.4);
        }

        /* General Button Styling (Eye-friendly) */
        QPushButton {
            background-color: #4A6572; /* Soft, muted gray-blue */
            color: #E0E5E8; /* Light text for contrast */
            font-size: 18px;
            padding: 12px 30px;
            border-radius: 14px;
            border: none;
            box-shadow: 0px 5px 12px rgba(74, 101, 114, 0.4);
            transition: all 0.3s ease-in-out;
            text-align: center;
        }

        /* Button Hover Effect */
        QPushButton:hover {
            background-color: #5A7581; /* Slightly lighter gray-blue */
            box-shadow: 0px 8px 20px rgba(90, 117, 129, 0.4);
            cursor: pointer;
            transform: translateY(-2px);
        }

        /* Button Pressed Effect */
        QPushButton:pressed {
            background-color: #4A6572;
            box-shadow: inset 0px 4px 8px rgba(0, 0, 0, 0.3);
            transform: scale(0.98);
        }

        /* Start Game Button Styling */
        QPushButton#startGameButton {
            background-color: #76EEC6; /* Soft green for gentle interaction */
            color: #1D1F21; /* Dark text for better readability */
        }

        QPushButton#startGameButton:hover {
            background-color: #64D4A8;
            box-shadow: 0px 10px 20px rgba(118, 238, 198, 0.4);
        }

        /* Manual Button Styling */
        QPushButton#manualButton {
            background-color: #FFB946; /* Warm orange, comforting */
            color: #1D1F21; /* Dark text for better readability */
        }

        QPushButton#manualButton:hover {
            background-color: #FFA500;
            box-shadow: 0px 10px 20px rgba(255, 185, 70, 0.4);
        }

        /* Quit Button Styling */
        QPushButton#quitButton {
            background-color: #FF6B6B; /* Soft red */
            color: #1D1F21; /* Dark text for better readability */
        }

        QPushButton#quitButton:hover {
            background-color: #FF4444;
            box-shadow: 0px 10px 20px rgba(255, 105, 105, 0.4);
        }

        /* Focus States */
        QPushButton:focus, QLineEdit:focus {
            outline: none;
            border: none;
        }

        /* Tab Bar Styling */
        QTabBar::tab {
            background-color: #4A5B6D; /* Gentle grayish blue */
            color: #F1F5F9;
            padding: 8px 20px;
            border-radius: 8px;
            margin: 2px;
            font-size: 14px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        QTabBar::tab:hover {
            background-color: #6C9DFF;
            color: white;
        }

        QTabBar::tab:selected {
            background-color: #3E5363;
            color: white;
            font-weight: bold;
        }

        /* Input Field Styling */
        QLineEdit {
            background-color: #3E5363;
            color: white;
            padding: 12px;
            border-radius: 10px;
            border: 2px solid #6C9DFF;
            font-size: 16px;
        }

        QLineEdit:focus {
            border: 2px solid #6C9DFF;
            box-shadow: 0px 5px 15px rgba(108, 157, 255, 0.4);
        }

        /* Slider Styling */
        QSlider {
            height: 8px;
            background: #3E5363;
            border-radius: 4px;
        }

        QSlider::handle {
            background-color: #76EEC6;
            border: 2px solid #64D4A8;
            border-radius: 10px;
            width: 20px;
            height: 20px;
        }

        QSlider::handle:hover {
            background-color: #64D4A8;
        }

        /* Tooltip Styling */
        QToolTip {
            background-color: #6C9DFF;
            color: white;
            border-radius: 6px;
            padding: 5px;
            font-size: 12px;
        }

        /* General Widget Hover Effect */
        QWidget:hover {
            background-color: #394B5A;
            transition: background-color 0.4s ease;
        }

        /* Transition for Widgets */
        QWidget {
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }
    )";

    this->setStyleSheet(style);
}



void MainWindow::on_playGame1Button_clicked() {
    if (gameRunning) {
        QMessageBox::warning(this, "Warning", "A game is already running. Please close it first.");
        return;
    }

    gameRunning = true;

    Game1 *game1Window = new Game1(this);
    game1Window->setAttribute(Qt::WA_DeleteOnClose); // Ensure the dialog is deleted when closed

    connect(game1Window, &QDialog::finished, this, [this]() {
        gameRunning = false; // Reset the flag when the game finishes
    });

    game1Window->exec(); // Open the dialog in modal mode
}

void MainWindow::on_playGame2Button_clicked() {
    if (gameRunning) {
        QMessageBox::warning(this, "Warning", "A game is already running. Please close it first.");
        return;
    }

    gameRunning = true;

    Game2 *game2Window = new Game2(this);
    game2Window->setAttribute(Qt::WA_DeleteOnClose); // Ensure the dialog is deleted when closed

    connect(game2Window, &QDialog::finished, this, [this]() {
        gameRunning = false; // Reset the flag when the game finishes
    });

    game2Window->exec(); // Open the dialog in modal mode
}


