#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void applyStylesheet();
    void on_startGameButton_clicked();
    void on_manualButton_clicked();  // Slot for the manualButton click
    void on_quitButton_clicked();    // Slot for the quitButton click

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
