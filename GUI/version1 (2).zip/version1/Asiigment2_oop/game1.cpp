#include "game1.h"
#include "ui_game1.h"
#include "games_menu.h"
#include <QInputDialog>
#include <QMessageBox>
#include <QVBoxLayout>

Game1::Game1(QWidget *parent) : QDialog(parent), ui(new Ui::Game1) {
    ui->setupUi(this);
    // Hide boardWidget initially
    ui->boardWidget->hide();
    // Hide current player label
    ui->currentPlayerLabel->hide();

    // Create a vertical layout for centering the grid
    QVBoxLayout *boardLayout = new QVBoxLayout(ui->boardWidget);
    boardLayout->setAlignment(Qt::AlignCenter); // Center align the grid
    ui->boardWidget->setLayout(boardLayout);

    // Set up the 4x4 grid within boardWidget
    const int gridSize = 4;
    const int cellSize = 90;
    QGridLayout *gridLayout = new QGridLayout();
    gridLayout->setSpacing(10); // Space between buttons
    gridLayout->setContentsMargins(0, 0, 0, 0); // Remove margins

    for (int row = 0; row < gridSize; ++row) {
        for (int col = 0; col < gridSize; ++col) {
            QPushButton *cellButton = new QPushButton(ui->boardWidget);
            cellButton->setFixedSize(cellSize, cellSize);
            cellButton->setStyleSheet(
                "QPushButton {"
                "background-color: #B2FF59;"      // Light green background
                "border-radius: 20px;"
                "border: 3px solid #66BB6A;"     // Green border
                "font-size: 30px;"
                "font-weight: bold;"
                "color: #388E3C;"                // Green text color
                "} "
                "QPushButton:hover {"
                "background-color: #A5D6A7;"     // Lighter green on hover
                "} "
                "QPushButton:pressed {"
                "background-color: #81C784;"     // Even lighter green on press
                "border: 3px solid #388E3C;"
                "} ");

            gridLayout->addWidget(cellButton, row, col);

            // Store in an array for further management
            gridButtons[row][col] = cellButton;

            // Connect to the click handler
            connect(cellButton, &QPushButton::clicked, this, [this, cellButton]() {
                handleCellClick(cellButton);
            });
        }
    }

    // Add the grid layout to the vertical layout
    boardLayout->addLayout(gridLayout);

    currentPlayer = "Player 1";
    currentSymbol = "X";
    updatePlayerLabel();
    ui->newGameButton->hide();
}

void Game1::on_helpButton_clicked() {
    // Implement help button functionality
    QMessageBox::information(this, "Help", "This is the help message for the game.");
}

void Game1::on_backButton_clicked() {
    GamesMenu *gamesMenu = new GamesMenu(this);
    gamesMenu->show();
    this->close();
}

Game1::~Game1() {
    delete ui;
}

void Game1::on_playVsRandomButton_clicked() {
    bool ok;
    player1Name = QInputDialog::getText(this, "Player 1 Name", "Enter Player 1's name:", QLineEdit::Normal, "", &ok);
    if (!ok || player1Name.isEmpty()) return;

    player2Name = "Mr. Habida";
    QStringList symbols = {"X", "O"};
    player1Symbol = QInputDialog::getItem(this, "Choose Symbol", "Choose Player 1's symbol:", symbols, 0, false, &ok);
    if (!ok || player1Symbol.isEmpty()) return;

    symbols.removeAll(player1Symbol);
    player2Symbol = symbols[0];

    currentPlayer = player1Name;
    currentSymbol = player1Symbol;
    updatePlayerLabel();

    ui->playVsRandomButton->setVisible(false);
    ui->playVsSecondButton->setVisible(false);
    ui->newGameButton->setVisible(true);
    ui->boardWidget->show();
    ui->currentPlayerLabel->show();
}

void Game1::on_playVsSecondButton_clicked() {
    bool ok;
    player1Name = QInputDialog::getText(this, "Player 1 Name", "Enter Player 1's name:", QLineEdit::Normal, "", &ok);
    if (!ok || player1Name.isEmpty()) return;

    player2Name = QInputDialog::getText(this, "Player 2 Name", "Enter Player 2's name:", QLineEdit::Normal, "", &ok);
    if (!ok || player2Name.isEmpty()) return;

    QStringList symbols = {"X", "O"};
    player1Symbol = QInputDialog::getItem(this, "Choose Symbol", "Choose Player 1's symbol:", symbols, 0, false, &ok);
    if (!ok || player1Symbol.isEmpty()) return;

    symbols.removeAll(player1Symbol);
    player2Symbol = symbols[0];

    currentPlayer = player1Name;
    currentSymbol = player1Symbol;
    updatePlayerLabel();

    ui->playVsRandomButton->setVisible(false);
    ui->playVsSecondButton->setVisible(false);
    ui->newGameButton->setVisible(true);
    ui->boardWidget->show();
    ui->currentPlayerLabel->show();
}

void Game1::handleCellClick(QPushButton *cellButton) {
    if (cellButton->text().isEmpty()) {
        cellButton->setText(currentSymbol);
        cellButton->setStyleSheet(
            currentSymbol == "X"
                ? "color: red; font-size: 24px; font-weight: bold;"
                : "color: blue; font-size: 24px; font-weight: bold;"
            );

        if (checkWinner()) {
            QMessageBox::information(this, "Game Over", currentPlayer + " wins!");
            resetBoard();
        } else {
            currentPlayer = (currentPlayer == player1Name) ? player2Name : player1Name;
            currentSymbol = (currentSymbol == player1Symbol) ? player2Symbol : player1Symbol;
            updatePlayerLabel();
        }
    }
}

void Game1::updatePlayerLabel() {
    ui->currentPlayerLabel->setText("Current Player: " + currentPlayer);
}

bool Game1::checkWinner() {
    // Implement logic to check the winner based on gridButtons
    return false;
}

void Game1::on_newGameButton_clicked() {
    resetBoard();
    ui->playVsRandomButton->setVisible(true);
    ui->playVsSecondButton->setVisible(true);
    ui->newGameButton->setVisible(false);
    ui->boardWidget->hide();
    ui->currentPlayerLabel->hide();
}

void Game1::resetBoard() {
    for (int row = 0; row < 4; ++row) {
        for (int col = 0; col < 4; ++col) {
            QPushButton *cellButton = gridButtons[row][col];
            if (cellButton) {
                cellButton->setText("");
                cellButton->setStyleSheet(
                    "QPushButton {"
                    "background-color: #B2FF59;"
                    "border-radius: 20px;"
                    "border: 3px solid #66BB6A;"
                    "font-size: 30px;"
                    "font-weight: bold;"
                    "color: #388E3C;"
                    "} "
                    "QPushButton:hover {"
                    "background-color: #A5D6A7;"
                    "} "
                    "QPushButton:pressed {"
                    "background-color: #81C784;"
                    "border: 3px solid #388E3C;"
                    "} ");
            }
        }
    }
}
