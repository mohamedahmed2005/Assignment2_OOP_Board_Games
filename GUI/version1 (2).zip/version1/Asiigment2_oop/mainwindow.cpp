#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "games_menu.h"
#include <QMessageBox>
#include <QCloseEvent>
#include <QFile>
#include <QTextStream>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    applyStylesheet();  // Apply the custom styles
    // QPixmap pixmap(":/images/beemo.png");
    // if (pixmap.isNull()) {
        // qDebug() << "Failed to load image!";
    // } else {
        // qDebug() << "Image loaded successfully!";
    // }
    // ui->beemo->setPixmap(pixmap);
    // ui->beemo->setPixmap(pixmap.scaled(ui->beemo->size(), Qt::KeepAspectRatio));
    ui->beemo->setFixedSize(300, 300);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_startGameButton_clicked() {
    GamesMenu *gamesMenu = new GamesMenu(this);
    gamesMenu->show();
    this->hide();
}

void MainWindow::on_manualButton_clicked()
{
    // Display the manual (this can be changed to show a dialog or a help page)
    QMessageBox::information(this, "Game Manual", "This is the XO Game. Play by selecting a cell to mark with X or O.");
}
void MainWindow::on_quitButton_clicked()
{
    // Confirm quit and close the application
    int ret = QMessageBox::warning(this, "Quit", "Are you sure you want to quit?",
                                   QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (ret == QMessageBox::Yes)
        QApplication::quit();
}

void MainWindow::applyStylesheet() {
    QString style = R"(
        /* Main Window Styling */
        QMainWindow {
            background-color: #1F2A44;
            color: #F1F1F1;
            border-radius: 10px;
            font-family: 'Arial', sans-serif;
        }

        /* QLabel (Beemo Image) Styling */
        QLabel#beemo {
            border-radius: 50%;
            border: 5px solid #F39C12;
            box-shadow: 0px 0px 15px rgba(255, 165, 0, 0.7);
            background-color: #2C3E50;
        }

        /* Button Styling */
        QPushButton {
            background-color: #3498DB;
            color: white;
            font-size: 18px;
            padding: 15px 30px;
            border-radius: 12px;
            border: none;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease-in-out;
            text-align: center;
        }

        QPushButton:hover {
            background-color: #2980B9;
            cursor: pointer;
            box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.4);
        }

        QPushButton:pressed {
            background-color: #1F618D;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.5);
            transform: scale(0.98);
        }

        /* Start Game Button Styling */
        QPushButton#startGameButton {
            background-color: #2ECC71;
        }

        QPushButton#startGameButton:hover {
            background-color: #27AE60;
        }

        /* Manual Button Styling */
        QPushButton#manualButton {
            background-color: #F39C12;
        }

        QPushButton#manualButton:hover {
            background-color: #E67E22;
        }

        /* Quit Button Styling */
        QPushButton#quitButton {
            background-color: #E74C3C;
        }

        QPushButton#quitButton:hover {
            background-color: #C0392B;
        }

        /* General MessageBox Styling */
        QMessageBox {
            background-color: #34495E;
            color: #ECF0F1;
            border-radius: 10px;
            font-size: 16px;
        }

        /* Slider Styling (for later use, e.g., game difficulty) */
        QSlider {
            background-color: #34495E;
            height: 6px;
            border-radius: 3px;
        }

        QSlider::handle {
            background-color: #3498DB;
            border-radius: 5px;
            width: 20px;
            height: 20px;
        }

        /* General Widget Styling (like the background of the central area) */
        QWidget {
            background-color: #2C3E50;
            border-radius: 10px;
        }

        /* Focused Buttons */
        QPushButton:focus {
            outline: none;
        }

        /* Active Button Text */
        QPushButton:active {
            font-weight: bold;
        }

        /* Window Title */
        QMainWindow::title {
            color: #ECF0F1;
            font-size: 18px;
            font-weight: bold;
        }

        /* Dynamic Transitions for All Widgets */
        QWidget:hover {
            background-color: #34495E;
            transition: background-color 0.3s ease;
        }

        /* Fancy Tooltip Styling */
        QToolTip {
            background-color: #16A085;
            color: white;
            border: 1px solid #16A085;
            font-size: 12px;
            border-radius: 5px;
            padding: 5px;
        }

        /* Active / Selected Button States */
        QPushButton:selected {
            background-color: #1ABC9C;
        }

        /* Custom Border Radius */
        QWidget#centralwidget {
            border-radius: 20px;
            background-color: #34495E;
        }

        /* Overall Body Shadows */
        QMainWindow {
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.4);
        }

        /* Textfield Styling (if needed later for user input) */
        QLineEdit {
            background-color: #34495E;
            color: #F1F1F1;
            padding: 10px;
            border-radius: 8px;
            border: 2px solid #3498DB;
            font-size: 16px;
        }

        QLineEdit:focus {
            border: 2px solid #2980B9;
        }
    )";

    this->setStyleSheet(style);  // Apply the style to the main window
}
